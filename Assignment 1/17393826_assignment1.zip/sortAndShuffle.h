int insertSongs(char songs[][80], char artist[]);

void sortArtists(char sortedArtists[][80], int numOfArtists);

void sortSongs(char songsOfAnArtist[][80], int numOfSongs);

void shuffleSongs(char songsToBeShuffled[][80], int numOfSongs);
